

function openNav() {
    document.getElementById("myNav").style.height = "220px";
	document.getElementById("open").style.display = "none";
}

function closeNav() {
    document.getElementById("myNav").style.height = "0%";
	document.getElementById("open").style.display = "block";
	
}
